package com.example.autoschem;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.world.World;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Predicate;
import java.util.function.ToDoubleFunction;

/** A* over standable feet positions: walk, 1-block step-up, up to 3-block drop. Avoids fluids, fire, cobweb, magma, cactus. */
public final class Pathfinder {
    private static final Direction[] H = {Direction.NORTH, Direction.SOUTH, Direction.EAST, Direction.WEST};
    private static final Set<Block> HAZARD = Set.of(Blocks.FIRE, Blocks.SOUL_FIRE, Blocks.COBWEB,
            Blocks.SWEET_BERRY_BUSH, Blocks.WITHER_ROSE, Blocks.POWDER_SNOW);
    private static final Set<Block> BAD_GROUND = Set.of(Blocks.MAGMA_BLOCK, Blocks.CACTUS,
            Blocks.CAMPFIRE, Blocks.SOUL_CAMPFIRE);

    private Pathfinder() {}

    private static final class Node {
        final BlockPos pos; final double g, f; final Node parent;
        Node(BlockPos pos, double g, double f, Node parent) { this.pos = pos; this.g = g; this.f = f; this.parent = parent; }
    }

    public static boolean passable(World w, BlockPos p) {
        BlockState s = w.getBlockState(p);
        if (!s.getFluidState().isEmpty()) return false;
        if (!s.getCollisionShape(w, p).isEmpty()) return false;
        return !HAZARD.contains(s.getBlock());
    }

    private static boolean solidGround(World w, BlockPos p) {
        BlockState s = w.getBlockState(p);
        if (BAD_GROUND.contains(s.getBlock())) return false;
        if (!s.getFluidState().isEmpty()) return false;
        return !s.getCollisionShape(w, p).isEmpty();
    }

    public static boolean standable(World w, BlockPos p) {
        return passable(w, p) && passable(w, p.up()) && solidGround(w, p.down());
    }

    private static void expand(World w, BlockPos p, BiConsumer<BlockPos, Double> out) {
        for (Direction d : H) {
            BlockPos flat = p.offset(d);
            if (standable(w, flat)) {
                out.accept(flat, 1.0);
            } else if (passable(w, flat) && passable(w, flat.up())) {
                for (int k = 1; k <= 3; k++) {              // drop down
                    BlockPos b = flat.down(k);
                    if (standable(w, b)) { out.accept(b, 1.0 + k); break; }
                    if (!passable(w, b)) break;
                }
            }
            BlockPos up = flat.up();                         // step up
            if (standable(w, up) && passable(w, p.up(2))) out.accept(up, 2.0);
        }
    }

    /** Returns the positions to walk through (start excluded), a partial path towards the goal, or null. */
    public static List<BlockPos> find(World w, BlockPos start, Predicate<BlockPos> goal,
                                      ToDoubleFunction<BlockPos> heuristic, int maxNodes) {
        PriorityQueue<Node> open = new PriorityQueue<>(Comparator.comparingDouble(n -> n.f));
        Map<Long, Double> bestG = new HashMap<>();
        Node startNode = new Node(start, 0, heuristic.applyAsDouble(start), null);
        open.add(startNode);
        bestG.put(start.asLong(), 0.0);
        Node best = startNode;
        double bestH = heuristic.applyAsDouble(start);
        int expanded = 0;

        while (!open.isEmpty() && expanded++ < maxNodes) {
            final Node cur = open.poll();
            if (cur.g > bestG.getOrDefault(cur.pos.asLong(), Double.MAX_VALUE)) continue; // stale entry
            if (goal.test(cur.pos)) return rebuild(cur);
            double h = heuristic.applyAsDouble(cur.pos);
            if (h < bestH) { bestH = h; best = cur; }
            expand(w, cur.pos, (np, cost) -> {
                double ng = cur.g + cost;
                long key = np.asLong();
                if (ng < bestG.getOrDefault(key, Double.MAX_VALUE)) {
                    bestG.put(key, ng);
                    open.add(new Node(np, ng, ng + heuristic.applyAsDouble(np), cur));
                }
            });
        }
        return best == startNode ? null : rebuild(best);
    }

    private static List<BlockPos> rebuild(Node end) {
        LinkedList<BlockPos> path = new LinkedList<>();
        for (Node n = end; n.parent != null; n = n.parent) path.addFirst(n.pos);
        return new ArrayList<>(path);
    }
}
