package com.example.autoschem;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.command.argument.BlockArgumentParser;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtSizeTracker;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;

import java.io.IOException;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Loads Sponge .schem (v2 + v3, i.e. WorldEdit / FAWE / Litematica-export). Blocks are stored bottom-up. */
public final class Schematic {
    public record Entry(BlockPos rel, BlockState state) {}
    public record Material(Item item, int count) {}

    public final int width, height, length;
    public final List<Entry> blocks = new ArrayList<>();

    private Schematic(int w, int h, int l) { width = w; height = h; length = l; }

    /** Items needed to build this schematic, biggest stack first. */
    public List<Material> materials() {
        Map<Item, Integer> m = new LinkedHashMap<>();
        for (Entry e : blocks) {
            BlockState st = e.state();
            if (BlockUtil.isSecondaryHalf(st)) continue;
            Item it = BlockUtil.itemOf(st);
            if (it == Items.AIR) continue; // fluids, piston heads, etc.
            m.merge(it, BlockUtil.isDoubleSlab(st) ? 2 : 1, Integer::sum);
        }
        List<Material> out = new ArrayList<>();
        m.forEach((k, v) -> out.add(new Material(k, v)));
        out.sort((a, b) -> Integer.compare(b.count(), a.count()));
        return out;
    }

    public static Schematic load(Path file) throws IOException {
        NbtCompound root = NbtIo.readCompressed(file, NbtSizeTracker.ofUnlimitedBytes());
        NbtCompound s = root.getCompound("Schematic").orElse(root); // v3 nests everything under "Schematic"

        int w = s.getInt("Width", 0), h = s.getInt("Height", 0), l = s.getInt("Length", 0);

        NbtCompound paletteTag;
        byte[] data;
        NbtCompound b = s.getCompound("Blocks").orElse(null); // v3
        if (b != null) {
            paletteTag = b.getCompound("Palette").orElse(null);
            data = b.getByteArray("Data").orElse(null);
        } else {                                              // v2
            paletteTag = s.getCompound("Palette").orElse(null);
            data = s.getByteArray("BlockData").orElse(null);
        }
        if (w <= 0 || h <= 0 || l <= 0 || paletteTag == null || data == null) {
            throw new IOException("Not a Sponge .schem file (.litematic / old .schematic not supported)");
        }

        Map<Integer, BlockState> palette = new HashMap<>();
        for (String key : paletteTag.keySet()) {
            int id = paletteTag.getInt(key, 0);
            BlockState st;
            try {
                st = BlockArgumentParser.block(Registries.BLOCK, key, false).blockState();
            } catch (CommandSyntaxException e) {
                st = Blocks.AIR.getDefaultState();
            }
            palette.put(id, st);
        }

        Schematic out = new Schematic(w, h, l);
        int total = w * h * l, i = 0, idx = 0;
        while (i < data.length && idx < total) {
            int val = 0, shift = 0, bt;
            do {
                bt = data[i++];
                val |= (bt & 0x7F) << shift;
                shift += 7;
            } while ((bt & 0x80) != 0 && i < data.length);

            BlockState st = palette.get(val);
            if (st != null && !st.isAir()) {
                int x = idx % w, z = (idx / w) % l, y = idx / (w * l);
                out.blocks.add(new Entry(new BlockPos(x, y, z), st));
            }
            idx++;
        }
        return out;
    }
}
