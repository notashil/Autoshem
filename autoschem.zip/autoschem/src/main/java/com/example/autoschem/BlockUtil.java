package com.example.autoschem;

import net.minecraft.block.*;
import net.minecraft.block.enums.BedPart;
import net.minecraft.block.enums.DoubleBlockHalf;
import net.minecraft.block.enums.SlabType;
import net.minecraft.item.Item;
import net.minecraft.state.property.Properties;
import net.minecraft.state.property.Property;

import java.util.Objects;
import java.util.Set;

public final class BlockUtil {
    /** Properties the game derives from neighbours / redstone / interaction, not from how the block was placed. */
    private static final Set<String> LOOSE = Set.of(
            "waterlogged", "powered", "distance", "persistent", "snowy", "power",
            "open", "lit", "hinge", "triggered");
    private static final Set<String> SIDES = Set.of("north", "east", "south", "west", "up");

    private BlockUtil() {}

    public static Item itemOf(BlockState s) { return s.getBlock().asItem(); }

    /** Upper door/plant halves and bed heads are placed automatically together with the first half. */
    public static boolean isSecondaryHalf(BlockState s) {
        if (s.contains(Properties.DOUBLE_BLOCK_HALF) && s.get(Properties.DOUBLE_BLOCK_HALF) == DoubleBlockHalf.UPPER) return true;
        return s.getBlock() instanceof BedBlock && s.get(BedBlock.PART) == BedPart.HEAD;
    }

    public static boolean isDoubleSlab(BlockState s) {
        return s.getBlock() instanceof SlabBlock && s.get(SlabBlock.TYPE) == SlabType.DOUBLE;
    }

    private static boolean isLoose(Block b, Property<?> p) {
        String n = p.getName();
        if (LOOSE.contains(n)) return true;
        if (n.equals("shape") && (b instanceof StairsBlock || b instanceof AbstractRailBlock)) return true;
        if (n.equals("type") && b instanceof ChestBlock) return true;
        return SIDES.contains(n) && (b instanceof HorizontalConnectingBlock || b instanceof WallBlock
                || b instanceof RedstoneWireBlock);
    }

    /** True when 'actual' is the same block with the same placement-defined state as 'target'. */
    public static boolean matches(BlockState actual, BlockState target) {
        if (actual.getBlock() != target.getBlock()) return false;
        for (Property<?> p : target.getBlock().getStateManager().getProperties()) {
            if (isLoose(target.getBlock(), p)) continue;
            if (!Objects.equals(actual.get(p), target.get(p))) return false;
        }
        return true;
    }
}
