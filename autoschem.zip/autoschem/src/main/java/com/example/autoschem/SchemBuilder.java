package com.example.autoschem;

import net.minecraft.block.BlockState;
import net.minecraft.block.FallingBlock;
import net.minecraft.block.ShapeContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemPlacementContext;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.*;

/**
 * Places blocks physically (walk -> aim -> sneak-place -> verify), so the result matches what a player could build.
 * Block states are pre-simulated with the game's own placement code before every click, every placement is
 * verified, wrong blocks are broken and redone, and a final full-schematic check re-queues anything missing.
 */
public final class SchemBuilder {
    private enum Phase { PICK, WALK, AIM, PLACE, VERIFY, BREAK, WAIT }

    private record Plan(BlockPos neighbor, Direction face, Vec3d hit, float yaw, float pitch) {
        BlockHitResult hitResult() { return new BlockHitResult(hit, face, neighbor, false); }
    }

    private static final double REACH = 4.0;       // conservative (vanilla allows 4.5)
    private static final double SNEAK_EYE = 1.27;
    private static final int MAX_ATTEMPTS = 3;

    public Schematic schematic;
    public BlockPos origin;
    public boolean running;
    public final Set<Item> ticked = new HashSet<>();

    private final List<Schematic.Entry> queue = new ArrayList<>();
    private final Map<Long, Integer> attempts = new HashMap<>();
    private final Map<Long, Long> deferUntil = new HashMap<>();
    private final Set<Long> failedSet = new HashSet<>();
    private final List<BlockPos> failed = new ArrayList<>();
    private final Set<Item> warnedMissing = new HashSet<>();

    private Phase phase = Phase.PICK;
    private Schematic.Entry cur;
    private BlockPos curPos;
    private Plan plan;
    private Vec3d goal;
    private boolean breaking;
    private List<BlockPos> path;
    private int pathIdx, replans, stuckTicks, ticks, passes, idleTicks, total, placedCount;
    private Vec3d lastPos = Vec3d.ZERO;
    private long now;

    // ------------------------------------------------------------------ control

    public void start() {
        queue.clear(); attempts.clear(); deferUntil.clear(); failedSet.clear(); failed.clear(); warnedMissing.clear();
        for (Schematic.Entry e : schematic.blocks) if (!BlockUtil.isSecondaryHalf(e.state())) queue.add(e);
        total = queue.size(); placedCount = 0; passes = 0; idleTicks = 0;
        phase = Phase.PICK; cur = null; plan = null; path = null;
        running = true;
    }

    public void stop() {
        running = false;
        setKeys(MinecraftClient.getInstance(), false, false, false);
    }

    public String status() {
        if (schematic == null) return "No schematic loaded (/schem load <file>)";
        return (running ? "Building" : "Idle") + " | " + placedCount + "/" + total + " done | queue " + queue.size()
                + " | failed " + failed.size() + " | origin " + (origin == null ? "not set" : origin.toShortString());
    }

    // ------------------------------------------------------------------ tick

    public void tick(MinecraftClient mc) {
        now++;
        if (!running) return;
        ClientPlayerEntity p = mc.player;
        if (p == null || mc.world == null || mc.interactionManager == null || schematic == null || origin == null) {
            running = false;
            return;
        }
        switch (phase) {
            case PICK -> pick(mc, p);
            case WALK -> walk(mc, p);
            case AIM -> aim(mc, p);
            case PLACE -> place(mc, p);
            case VERIFY -> verify(mc, p);
            case BREAK -> breakBlock(mc, p);
            case WAIT -> { if (++ticks >= 20) phase = Phase.PICK; }
        }
    }

    // ------------------------------------------------------------------ PICK

    private void pick(MinecraftClient mc, ClientPlayerEntity p) {
        World w = mc.world;
        boolean creative = p.isCreative();
        if (queue.isEmpty()) { verifyPass(mc, p); return; }

        Schematic.Entry best = null;
        double bestScore = Double.MAX_VALUE;
        int lowestY = Integer.MIN_VALUE, scanned = 0;
        boolean sawMissing = false;

        Iterator<Schematic.Entry> it = queue.iterator();
        while (it.hasNext() && scanned < 800) {
            Schematic.Entry e = it.next();
            if (isDone(w, e)) { it.remove(); placedCount++; continue; }
            scanned++;
            if (lowestY == Integer.MIN_VALUE) lowestY = e.rel().getY();
            BlockPos pos = origin.add(e.rel());
            if (deferUntil.getOrDefault(pos.asLong(), 0L) > now) continue;
            if (!w.getChunkManager().isChunkLoaded(pos.getX() >> 4, pos.getZ() >> 4)) continue;
            Item item = BlockUtil.itemOf(e.state());
            if (item == Items.AIR) { markFailed(pos); it.remove(); continue; }
            if (!creative && !hasItem(p, item)) {
                sawMissing = true;
                if (warnedMissing.add(item)) msg(p, "Need more: " + item.getName().getString());
                continue;
            }
            double score = (e.rel().getY() - lowestY) * 10000.0 + p.getPos().squaredDistanceTo(Vec3d.ofCenter(pos));
            if (score < bestScore) { bestScore = score; best = e; }
        }

        if (best == null) {
            if (queue.isEmpty()) return;
            if (!sawMissing) idleTicks += 20;
            if (idleTicks > 2400) { finish(mc, p, "nothing more can be placed"); return; }
            ticks = 0; phase = Phase.WAIT;
            return;
        }
        idleTicks = 0;

        cur = best;
        curPos = origin.add(best.rel());
        BlockState ws = w.getBlockState(curPos);
        breaking = !ws.isReplaceable();
        if (breaking) {
            if (ws.getHardness(w, curPos) < 0) { markFailed(curPos); queue.remove(cur); return; }
            plan = null;
            goal = Vec3d.ofCenter(curPos);
        } else {
            plan = findPlan(mc, p, curPos, cur.state());
            if (plan == null) { penalise(); return; }
            goal = plan.hit();
        }
        replans = 0;
        approach(mc, p);
    }

    // ------------------------------------------------------------------ plan (exact block state)

    private Plan findPlan(MinecraftClient mc, ClientPlayerEntity p, BlockPos pos, BlockState target) {
        World w = mc.world;
        if (target.getBlock() instanceof FallingBlock && FallingBlock.canFallThrough(w.getBlockState(pos.down()))) return null;
        ItemStack stack = new ItemStack(BlockUtil.itemOf(target));
        float oy = p.getYaw(), op = p.getPitch();
        try {
            for (Direction d : Direction.values()) {
                BlockPos n = pos.offset(d);
                BlockState ns = w.getBlockState(n);
                if (ns.isAir() || ns.isReplaceable() || !ns.getFluidState().isEmpty()) continue;
                Direction face = d.getOpposite();
                boolean side = face.getAxis().isHorizontal();
                for (double f : side ? new double[]{0.25, 0.75} : new double[]{0.5}) {
                    Vec3d hit = Vec3d.ofCenter(n).offset(face, 0.5);
                    if (side) hit = new Vec3d(hit.x, n.getY() + f, hit.z);
                    BlockHitResult bhr = new BlockHitResult(hit, face, n, false);
                    for (float pitch : new float[]{0f, 80f, -80f}) {
                        for (float yaw : new float[]{0f, 90f, 180f, 270f}) {
                            p.setYaw(yaw); p.setPitch(pitch);
                            ItemPlacementContext ctx = new ItemPlacementContext(p, Hand.MAIN_HAND, stack, bhr);
                            if (!ctx.getBlockPos().equals(pos) || !ctx.canPlace()) continue;
                            BlockState sim = target.getBlock().getPlacementState(ctx);
                            if (sim != null && BlockUtil.matches(sim, target) && sim.canPlaceAt(w, pos)) {
                                return new Plan(n, face, hit, yaw, pitch);
                            }
                        }
                    }
                }
            }
        } finally {
            p.setYaw(oy); p.setPitch(op);
        }
        return null;
    }

    // ------------------------------------------------------------------ approach / walk

    private static double eyeDist(BlockPos s, Vec3d t) {
        double dx = s.getX() + 0.5 - t.x, dy = s.getY() + SNEAK_EYE - t.y, dz = s.getZ() + 0.5 - t.z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz);
    }

    private static boolean conflict(BlockPos stand, BlockPos target) {
        return stand.equals(target) || stand.up().equals(target) || stand.down().equals(target);
    }

    private boolean atGoal(ClientPlayerEntity p) {
        double dx = p.getX() - goal.x, dy = p.getY() + SNEAK_EYE - goal.y, dz = p.getZ() - goal.z;
        return Math.sqrt(dx * dx + dy * dy + dz * dz) <= REACH && !conflict(p.getBlockPos(), curPos) && p.isOnGround();
    }

    private void approach(MinecraftClient mc, ClientPlayerEntity p) {
        if (atGoal(p)) { ticks = 0; phase = breaking ? Phase.BREAK : Phase.AIM; return; }
        if (replans++ >= 5) { abort(mc); return; }
        final Vec3d t = goal;
        final BlockPos tp = curPos;
        List<BlockPos> r = Pathfinder.find(mc.world, p.getBlockPos(),
                s -> eyeDist(s, t) <= REACH && !conflict(s, tp),
                s -> Math.max(0.0, eyeDist(s, t) - REACH + 0.3),
                8000);
        if (r == null || r.isEmpty()) { abort(mc); return; }
        path = r; pathIdx = 0; stuckTicks = 0; lastPos = p.getPos(); ticks = 0;
        phase = Phase.WALK;
    }

    private void walk(MinecraftClient mc, ClientPlayerEntity p) {
        if (path == null || pathIdx >= path.size()) { setKeys(mc, false, false, false); approach(mc, p); return; }
        BlockPos next = path.get(pathIdx);
        if (!Pathfinder.standable(mc.world, next)) { setKeys(mc, false, false, false); path = null; approach(mc, p); return; }

        Vec3d c = Vec3d.ofBottomCenter(next);
        double dx = c.x - p.getX(), dz = c.z - p.getZ();
        if (dx * dx + dz * dz < 0.09 && Math.abs(p.getY() - c.y) < 0.8) {
            pathIdx++; stuckTicks = 0;
            return;
        }
        p.setYaw((float) (MathHelper.atan2(-dx, dz) * 57.29577951308232));
        boolean jump = p.isOnGround() && (c.y > p.getY() + 0.3 || p.horizontalCollision);
        setKeys(mc, true, jump, false);

        if (++stuckTicks % 20 == 0) {
            if (p.getPos().squaredDistanceTo(lastPos) < 0.09) { setKeys(mc, false, false, false); path = null; approach(mc, p); return; }
            lastPos = p.getPos();
        }
    }

    // ------------------------------------------------------------------ AIM / PLACE / VERIFY

    private static boolean near(float a, float b) { return Math.abs(MathHelper.wrapDegrees(a - b)) < 0.01f; }

    private void aim(MinecraftClient mc, ClientPlayerEntity p) {
        setKeys(mc, false, false, true);
        boolean aimed = near(p.getYaw(), plan.yaw()) && near(p.getPitch(), plan.pitch());
        if (!aimed) { p.setYaw(plan.yaw()); p.setPitch(plan.pitch()); }
        // rotation set on an earlier tick has already been sent to the server; sneaking must be active too
        if (aimed && p.isSneaking()) { ticks = 0; phase = Phase.PLACE; return; }
        if (++ticks > 15) abort(mc);
    }

    private void place(MinecraftClient mc, ClientPlayerEntity p) {
        setKeys(mc, false, false, true);
        World w = mc.world;
        if (!w.getBlockState(curPos).isReplaceable()) { phase = Phase.PICK; return; }
        BlockState ns = w.getBlockState(plan.neighbor());
        if (ns.isAir() || ns.isReplaceable()) { phase = Phase.PICK; return; }
        if (!holdItem(mc, p, BlockUtil.itemOf(cur.state()))) {
            if (++ticks > 20) abort(mc);
            return;
        }
        if (!w.canPlace(cur.state(), curPos, ShapeContext.of(p))) { abort(mc); return; } // something stands in the spot
        ActionResult r = mc.interactionManager.interactBlock(p, Hand.MAIN_HAND, plan.hitResult());
        if (r.isAccepted()) p.swingHand(Hand.MAIN_HAND);
        ticks = 0;
        phase = Phase.VERIFY;
    }

    private void verify(MinecraftClient mc, ClientPlayerEntity p) {
        setKeys(mc, false, false, true);
        if (++ticks < 5) return; // give the server time to confirm or revert
        if (isDone(mc.world, cur)) { queue.remove(cur); placedCount++; phase = Phase.PICK; return; }
        if (ticks < 12 && mc.world.getBlockState(curPos).isReplaceable()) return;
        penalise(); // wrong or missing -> next PICK will break/redo it
    }

    private void breakBlock(MinecraftClient mc, ClientPlayerEntity p) {
        setKeys(mc, false, false, true);
        BlockState s = mc.world.getBlockState(curPos);
        if (s.isReplaceable()) { mc.interactionManager.cancelBlockBreaking(); ticks = 0; phase = Phase.PICK; return; }
        if (!atGoal(p)) { approach(mc, p); return; }
        if (ticks == 0) {                                   // pick the fastest tool in the hotbar
            PlayerInventory inv = p.getInventory();
            int bestSlot = inv.getSelectedSlot();
            float bestSpeed = 0;
            for (int i = 0; i < 9; i++) {
                float sp = inv.getStack(i).getMiningSpeedMultiplier(s);
                if (sp > bestSpeed) { bestSpeed = sp; bestSlot = i; }
            }
            inv.setSelectedSlot(bestSlot);
        }
        mc.interactionManager.updateBlockBreakingProgress(curPos, Direction.UP);
        p.swingHand(Hand.MAIN_HAND);
        if (++ticks > 400) { mc.interactionManager.cancelBlockBreaking(); abort(mc); }
    }

    // ------------------------------------------------------------------ finishing / verification

    private void verifyPass(MinecraftClient mc, ClientPlayerEntity p) {
        List<Schematic.Entry> missing = new ArrayList<>();
        for (Schematic.Entry e : schematic.blocks) {
            if (BlockUtil.isSecondaryHalf(e.state())) continue;
            BlockPos pos = origin.add(e.rel());
            if (failedSet.contains(pos.asLong())) continue;
            if (!isDone(mc.world, e)) missing.add(e);
        }
        if (missing.isEmpty() || passes >= 3) { finish(mc, p, null); return; }
        passes++;
        queue.addAll(missing);
        phase = Phase.PICK;
    }

    private void finish(MinecraftClient mc, ClientPlayerEntity p, String why) {
        running = false;
        setKeys(mc, false, false, false);
        int bad = 0;
        for (Schematic.Entry e : schematic.blocks) if (!isDone(mc.world, e)) bad++;
        msg(p, (why == null ? "Finished." : "Stopped: " + why + ".") + " Blocks not matching the schematic: " + bad
                + " | gave up on " + failed.size() + " position(s).");
        for (int i = 0; i < Math.min(5, failed.size()); i++) msg(p, "  could not place at " + failed.get(i).toShortString());
    }

    // ------------------------------------------------------------------ helpers

    private boolean isDone(World w, Schematic.Entry e) {
        return BlockUtil.matches(w.getBlockState(origin.add(e.rel())), e.state());
    }

    private void markFailed(BlockPos pos) {
        if (failedSet.add(pos.asLong())) failed.add(pos);
    }

    /** One more failed try for the current block: retry later, or give up after MAX_ATTEMPTS. */
    private void penalise() {
        int a = attempts.merge(curPos.asLong(), 1, Integer::sum);
        if (a >= MAX_ATTEMPTS) { markFailed(curPos); queue.remove(cur); }
        else deferUntil.put(curPos.asLong(), now + 40);
        phase = Phase.PICK;
    }

    private void abort(MinecraftClient mc) {
        setKeys(mc, false, false, false);
        penalise();
    }

    private static void msg(ClientPlayerEntity p, String s) {
        p.sendMessage(Text.literal("[AutoSchem] " + s), false);
    }

    private static void setKeys(MinecraftClient mc, boolean forward, boolean jump, boolean sneak) {
        mc.options.forwardKey.setPressed(forward);
        mc.options.jumpKey.setPressed(jump);
        mc.options.sneakKey.setPressed(sneak);
    }

    private static boolean hasItem(ClientPlayerEntity p, Item item) {
        PlayerInventory inv = p.getInventory();
        for (int i = 0; i < inv.size(); i++) if (inv.getStack(i).isOf(item)) return true;
        return false;
    }

    /** Puts the item in hand. Returns false while a slot swap / creative fill is still settling. */
    private boolean holdItem(MinecraftClient mc, ClientPlayerEntity p, Item item) {
        PlayerInventory inv = p.getInventory();
        if (p.isCreative()) {                                // slot 9 of the hotbar is reserved for the builder
            if (!inv.getStack(8).isOf(item)) {
                mc.interactionManager.clickCreativeStack(new ItemStack(item), 36 + 8);
                return false;
            }
            inv.setSelectedSlot(8);
            return true;
        }
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).isOf(item)) { inv.setSelectedSlot(i); return true; }
        }
        for (int i = 9; i < 36; i++) {
            if (inv.getStack(i).isOf(item)) {
                mc.interactionManager.clickSlot(p.playerScreenHandler.syncId, i, inv.getSelectedSlot(),
                        SlotActionType.SWAP, p);
                return false;
            }
        }
        return false;
    }
}
