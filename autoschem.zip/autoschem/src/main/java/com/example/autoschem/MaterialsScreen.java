package com.example.autoschem;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.CheckboxWidget;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.text.Text;

import java.util.List;

/** Materials checklist: tick what you've gathered; counts turn green when your inventory has enough. */
public class MaterialsScreen extends Screen {
    private static final int PER_PAGE = 8, ROW_H = 24, TOP = 48, WIDTH = 300;

    private final SchemBuilder b;
    private List<Schematic.Material> rows = List.of();
    private int page, pages = 1;

    public MaterialsScreen(SchemBuilder b) {
        super(Text.literal("AutoSchem - Materials"));
        this.b = b;
    }

    @Override
    protected void init() {
        rows = b.schematic == null ? List.of() : b.schematic.materials();
        pages = Math.max(1, (rows.size() + PER_PAGE - 1) / PER_PAGE);
        page = Math.max(0, Math.min(page, pages - 1));
        int left = width / 2 - WIDTH / 2;

        for (int i = 0; i < PER_PAGE; i++) {
            int idx = page * PER_PAGE + i;
            if (idx >= rows.size()) break;
            Item item = rows.get(idx).item();
            addDrawableChild(CheckboxWidget.builder(Text.empty(), textRenderer)
                    .pos(left, TOP + i * ROW_H)
                    .checked(b.ticked.contains(item))
                    .callback((box, checked) -> { if (checked) b.ticked.add(item); else b.ticked.remove(item); })
                    .build());
        }

        int by = TOP + PER_PAGE * ROW_H + 6;
        addDrawableChild(ButtonWidget.builder(Text.literal("<"), btn -> { page--; clearAndInit(); })
                .dimensions(left, by, 30, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(">"), btn -> { page++; clearAndInit(); })
                .dimensions(left + 34, by, 30, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Tick ready"), btn -> { tickReady(); clearAndInit(); })
                .dimensions(left + 70, by, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal(b.running ? "Stop" : "Start"), btn -> toggleBuild())
                .dimensions(left + 146, by, 70, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), btn -> close())
                .dimensions(left + 222, by, 78, 20).build());
    }

    private void toggleBuild() {
        if (b.running) {
            b.stop();
        } else if (b.schematic != null) {
            if (b.origin == null && client != null && client.player != null) b.origin = client.player.getBlockPos();
            b.start();
        }
        clearAndInit();
    }

    private boolean creative() { return client != null && client.player != null && client.player.isCreative(); }

    private int have(Item item) {
        if (client == null || client.player == null) return 0;
        PlayerInventory inv = client.player.getInventory();
        int n = 0;
        for (int i = 0; i < inv.size(); i++) {
            ItemStack s = inv.getStack(i);
            if (s.isOf(item)) n += s.getCount();
        }
        return n;
    }

    private void tickReady() {
        for (Schematic.Material m : rows) if (creative() || have(m.item()) >= m.count()) b.ticked.add(m.item());
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double h, double v) {
        if (v != 0) { page += v > 0 ? -1 : 1; clearAndInit(); }
        return true;
    }

    @Override
    public boolean shouldPause() { return false; } // keep the game (and the builder) running

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        super.render(ctx, mouseX, mouseY, delta);
        int left = width / 2 - WIDTH / 2;
        ctx.drawCenteredTextWithShadow(textRenderer, title, width / 2, 14, 0xFFFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(b.status()), width / 2, 28, 0xFFAAAAAA);

        boolean creative = creative();
        for (int i = 0; i < PER_PAGE; i++) {
            int idx = page * PER_PAGE + i;
            if (idx >= rows.size()) break;
            Schematic.Material m = rows.get(idx);
            int y = TOP + i * ROW_H;
            int have = creative ? m.count() : have(m.item());
            ctx.drawItem(new ItemStack(m.item()), left + 26, y);
            ctx.drawTextWithShadow(textRenderer, m.item().getName(), left + 48, y + 4, 0xFFFFFFFF);
            String s = have + " / " + m.count();
            ctx.drawTextWithShadow(textRenderer, s, left + WIDTH - textRenderer.getWidth(s), y + 4,
                    have >= m.count() ? 0xFF55FF55 : 0xFFFF5555);
        }
        if (rows.isEmpty()) {
            ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Load a schematic first: /schem load <file>"),
                    width / 2, TOP + 20, 0xFFFFFFFF);
        }
        int ticked = 0;
        for (Schematic.Material m : rows) if (b.ticked.contains(m.item())) ticked++;
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("Page " + (page + 1) + "/" + pages + "   Ticked " + ticked + "/" + rows.size()
                        + (creative ? "   (creative: no materials needed)" : "")),
                width / 2, TOP + PER_PAGE * ROW_H + 32, 0xFFAAAAAA);
    }
}
