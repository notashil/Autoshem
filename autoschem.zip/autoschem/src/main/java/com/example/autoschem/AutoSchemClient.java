package com.example.autoschem;

import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;
import net.minecraft.text.Text;

import java.nio.file.Files;
import java.nio.file.Path;

import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.argument;
import static net.fabricmc.fabric.api.client.command.v2.ClientCommandManager.literal;

public class AutoSchemClient implements ClientModInitializer {
    public static final SchemBuilder BUILDER = new SchemBuilder();
    private static boolean openGui;

    // Shown under Options > Controls > Key Binds > "AutoSchem". Any keyboard key or mouse button can be assigned there.
    private static final KeyBinding.Category CATEGORY = KeyBinding.Category.create(Identifier.of("autoschem", "main"));
    private static KeyBinding openKey;
    private static KeyBinding toggleKey;

    @Override
    public void onInitializeClient() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.autoschem.open_gui",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_G, CATEGORY));
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.autoschem.toggle_build",
                InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_UNKNOWN, CATEGORY)); // unbound by default

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (openKey.wasPressed()) {
                if (mc.currentScreen == null) openGui = true;
            }
            while (toggleKey.wasPressed()) {
                if (mc.player == null) continue;
                if (BUILDER.running) {
                    BUILDER.stop();
                    mc.player.sendMessage(Text.literal("[AutoSchem] Stopped."), false);
                } else if (BUILDER.schematic != null) {
                    if (BUILDER.origin == null) BUILDER.origin = mc.player.getBlockPos();
                    BUILDER.start();
                    mc.player.sendMessage(Text.literal("[AutoSchem] Building at " + BUILDER.origin.toShortString()), false);
                } else {
                    mc.player.sendMessage(Text.literal("[AutoSchem] Load a schematic first: /schem load <file>"), false);
                }
            }
            if (openGui) { openGui = false; mc.setScreen(new MaterialsScreen(BUILDER)); } // also works after /schem gui
            BUILDER.tick(mc);
        });

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
            dispatcher.register(literal("schem")
                .then(literal("load").then(argument("file", StringArgumentType.greedyString()).executes(ctx -> {
                    var src = ctx.getSource();
                    try {
                        Path dir = FabricLoader.getInstance().getGameDir().resolve("schematics").normalize();
                        Files.createDirectories(dir);
                        Path file = dir.resolve(StringArgumentType.getString(ctx, "file")).normalize();
                        if (!file.startsWith(dir)) { src.sendFeedback(Text.literal("Invalid path.")); return 0; }
                        BUILDER.stop();
                        BUILDER.ticked.clear();
                        BUILDER.schematic = Schematic.load(file);
                        src.sendFeedback(Text.literal("Loaded " + BUILDER.schematic.width + "x" + BUILDER.schematic.height
                                + "x" + BUILDER.schematic.length + " (" + BUILDER.schematic.blocks.size()
                                + " blocks). /schem gui for materials, /schem here to set the origin."));
                    } catch (Exception e) {
                        src.sendFeedback(Text.literal("Load failed: " + e.getMessage()));
                    }
                    return 1;
                })))
                .then(literal("gui").executes(ctx -> { openGui = true; return 1; }))
                .then(literal("here").executes(ctx -> {
                    var p = MinecraftClient.getInstance().player;
                    if (p == null) return 0;
                    BUILDER.origin = p.getBlockPos();
                    ctx.getSource().sendFeedback(Text.literal("Origin set to " + BUILDER.origin.toShortString()));
                    return 1;
                }))
                .then(literal("start").executes(ctx -> {
                    var p = MinecraftClient.getInstance().player;
                    if (BUILDER.schematic == null || p == null) {
                        ctx.getSource().sendFeedback(Text.literal("Load a schematic first."));
                        return 0;
                    }
                    if (BUILDER.origin == null) BUILDER.origin = p.getBlockPos();
                    BUILDER.start();
                    ctx.getSource().sendFeedback(Text.literal("Building at " + BUILDER.origin.toShortString() + " ..."));
                    return 1;
                }))
                .then(literal("stop").executes(ctx -> {
                    BUILDER.stop();
                    ctx.getSource().sendFeedback(Text.literal("Stopped."));
                    return 1;
                }))
                .then(literal("status").executes(ctx -> {
                    ctx.getSource().sendFeedback(Text.literal(BUILDER.status()));
                    return 1;
                }))));
    }
}
